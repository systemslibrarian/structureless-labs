# sl-atlas

**An interactive learning site for post-quantum cryptography. The signature feature:
explainable PQC at three depths.**

This is, arguably, the most valuable repo in the lab — it can stay useful even if sl-kem
never becomes production crypto. The bet from the research arc (cipher-museum →
crypto-compare → crypto-lab → crypto-counsel) is that *making hard cryptography
approachable* is the durable contribution.

## The three-view contract
Every concept page renders three synchronized views:

- **Simple** — for a curious non-expert.
- **Developer** — for a programmer.
- **Researcher** — precise and formal.

Content is authored once in a structured format and the site renders all three.

## What users explore
Noise · Matrices · LWE · Encoding · Reconciliation · Attacks · Parameter choices —
visually, interactively. The research project teaches itself.

## Content source
Explainers are pulled from each project's `spec/EXPLAINER-*.md` files (see sl-kem),
so the Atlas never drifts from the actual specs. The Teacher persona gates new content.

## Build
Static site (Next.js-friendly, GitHub Pages deployable), consistent with the existing
crypto-lab portfolio: theme toggle, standard README, Pages config, scripture footer.

---
*Soli Deo Gloria — 1 Corinthians 10:31*
